The Sword Art Online Utilities Project
-Icon Set ver 0.3

Update Page: http://www.gpbeta.com/post/develop/sao-utils/

Change Log:

2013-08-04 v0.3:
+ Add 'Equipment' icons.
+ Add 'Items' icons.
+ Add 'Skills' icons.
+ Add 'Immortal Change' image.
- Remove mistaken 'Media' icons.
* Update 'Immortal' image.
* Fix spelling mistake in 'Welcome' image.

2012-11-13 v0.2:
* Rebuild all icons.

2012-11-13 v0.1:
* First release.

SAO Utils Icon Sets
by GPBeta
