package net.minecraft.src.forge;

import net.minecraft.src.NetworkManager;

public class PacketHandlerServer implements IPacketHandler
{
    @Override
    public void onPacketData(NetworkManager network, String channel, byte[] data) 
    {
    }
}
