*** HOW TO INSTALL ***

Extract the download archive directly into your MCP-directiory.
It should create a folder "forge" within that directory, containing all 
extracted files.

You should use freshly downloaded jars, solely including ModLoader & 
ModLoaderMP. Anything else can eventually cause conflicts.

Now just start the install.cmd/.sh, MCForge will install itself into the proper
locations and copy all needed files, as well as modifying the needed baseclasses.

Forge also includes a snapshot of the MCP mapings, this may not be the current 
version of the mapings. But you must use the provided mapings in order for the 
patch files to work together.

The install scripts should take care of everything for you, so you should not need
to run ANY MCP script before installing forge.

