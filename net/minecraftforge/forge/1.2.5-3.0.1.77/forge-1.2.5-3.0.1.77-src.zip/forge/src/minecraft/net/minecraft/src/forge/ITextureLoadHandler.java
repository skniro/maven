package net.minecraft.src.forge;

public interface ITextureLoadHandler 
{
    public void onTextureLoad(String textureName, int textureID);
}
