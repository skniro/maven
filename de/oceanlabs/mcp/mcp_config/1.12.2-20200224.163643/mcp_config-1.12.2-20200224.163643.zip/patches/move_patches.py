import os, shutil

def move_patches(src, dst):
    for filename in os.listdir(src):
        if filename.endswith('.java.patch'):
            newname = os.path.join(dst, filename[0:len(filename)-11].replace('.', os.path.sep) + '.java.patch')
            oldname = os.path.join(src, filename)
            dir = os.path.dirname(newname)
            if not os.path.isdir(dir):
                os.makedirs(dir)
            
            with open(oldname, 'r') as i:
                with open(newname, 'w') as o:
                    idx = 0
                    for line in i:
                        if (idx == 0):
                            idx = idx
                        elif (idx == 1):
                            o.write(line.replace('--- minecraft\\', '--- a/').replace('--- minecraft_server\\', '--- a/').replace('\\', '/'))
                        elif (idx == 2):
                            o.write(line.replace('+++ minecraft_patched\\', '+++ b/').replace('+++ minecraft_server_patched\\', '+++ b/').replace('\\', '/'))
                        else:
                            o.write(line)
                        idx += 1
                            
            print(newname)
            
move_patches('minecraft_ff', 'client')
move_patches('minecraft_merged_ff', 'joined')
move_patches('minecraft_server_ff', 'server')